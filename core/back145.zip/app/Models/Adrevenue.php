<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Adrevenue extends Model
{
    protected $table = 'adrevenue';
    public $timestamps = true;
}
