<footer class="footer-section pt-80 bg-overlay-black bg_img">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 text-center">
                <div class="col-lg-4">
                    well
                </div>
                <div class="col-lg-4">
                    well
                </div>
                <div class="col-lg-4">
                    well
                </div>
            </div>
        </div>
        <div class="footer-bottom-area">
            <div class="row justify-content-center">
                <div class="col-lg-12 text-center">
                    <p>{{__(@$footer->data_values->copyright)}}</p>
                </div>
            </div>
        </div>
    </div>
</footer>

